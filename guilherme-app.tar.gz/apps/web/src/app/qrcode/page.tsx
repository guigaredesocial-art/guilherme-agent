"use client";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function QRCodePage() {
  const [qr, setQr] = useState<string | null>(null);
  const [status, setStatus] = useState("Verificando...");
  const [loading, setLoading] = useState(true);

  async function checkStatus() {
    try {
      const res = await fetch("/api/health");
      const data = await res.json();
      setStatus(data.evolution);
      if (data.evolution === "WORKING") {
        setQr(null);
        return;
      }
      // Buscar QR
      const qrRes = await fetch("/api/whatsapp/qr");
      if (qrRes.ok) {
        const { qrcode } = await qrRes.json();
        setQr(qrcode);
      }
    } catch {
      setStatus("FAILED");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    checkStatus();
    const t = setInterval(checkStatus, 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ minHeight: "100vh", padding: "1.5rem", maxWidth: 600, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem" }}>
        <Link href="/dashboard" style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.875rem" }}>← Voltar</Link>
        <h1 style={{ fontWeight: 700 }}>Conectar WhatsApp</h1>
      </div>

      <div className="card" style={{ textAlign: "center" }}>
        <div style={{ marginBottom: "1rem" }}>
          <span className={status === "WORKING" ? "badge-online" : "badge-offline"}>
            {status === "WORKING" ? "WhatsApp Conectado ✓" : `Status: ${status}`}
          </span>
        </div>

        {status === "WORKING" ? (
          <div style={{ padding: "2rem", color: "#22c55e" }}>
            <div style={{ fontSize: "3rem" }}>✓</div>
            <p style={{ marginTop: "0.5rem" }}>WhatsApp conectado com sucesso!</p>
            <p style={{ color: "var(--muted)", fontSize: "0.875rem" }}>O agente Guilherme está ativo e respondendo.</p>
          </div>
        ) : qr ? (
          <div>
            <p style={{ color: "var(--muted)", fontSize: "0.875rem", marginBottom: "1rem" }}>
              Abra o WhatsApp no celular → Dispositivos conectados → Conectar dispositivo → Escaneie o QR:
            </p>
            <img
              src={`data:image/png;base64,${qr}`}
              alt="QR Code WhatsApp"
              style={{ width: 280, height: 280, margin: "0 auto", display: "block", borderRadius: "0.5rem" }}
            />
            <p style={{ color: "var(--muted)", fontSize: "0.75rem", marginTop: "1rem" }}>
              QR atualiza automaticamente a cada 5 segundos
            </p>
          </div>
        ) : (
          <p style={{ color: "var(--muted)", padding: "2rem" }}>
            {loading ? "Carregando QR Code..." : "Aguardando QR Code do Evolution API..."}
          </p>
        )}
      </div>
    </div>
  );
}
