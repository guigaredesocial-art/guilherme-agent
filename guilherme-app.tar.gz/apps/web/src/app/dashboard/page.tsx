"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Conversation {
  id: string;
  channel: string;
  aiEnabled: boolean;
  handoffRequested: boolean;
  updatedAt: string;
  contact: { displayName?: string };
  messages: Array<{ content: string; role: string }>;
}

interface Health {
  ok: boolean;
  evolution: string;
}

function getToken(): string {
  return document.cookie.split(";").find((c) => c.trim().startsWith("token="))?.split("=")[1] ?? "";
}

export default function DashboardPage() {
  const router = useRouter();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [health, setHealth] = useState<Health | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getToken();
    if (!token) { router.push("/"); return; }

    Promise.all([
      fetch("/api/conversations", { headers: { authorization: `Bearer ${token}` } })
        .then((r) => r.json())
        .then(setConversations),
      fetch("/api/health").then((r) => r.json()).then(setHealth),
    ])
      .catch(console.error)
      .finally(() => setLoading(false));

    const interval = setInterval(() => {
      const t = getToken();
      fetch("/api/conversations", { headers: { authorization: `Bearer ${t}` } })
        .then((r) => r.json()).then(setConversations).catch(() => {});
      fetch("/api/health").then((r) => r.json()).then(setHealth).catch(() => {});
    }, 10000);

    return () => clearInterval(interval);
  }, [router]);

  async function toggleAI(convId: string, current: boolean) {
    const token = getToken();
    await fetch(`/api/conversations/${convId}`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify({ aiEnabled: !current }),
    });
    setConversations((prev) => prev.map((c) => c.id === convId ? { ...c, aiEnabled: !current } : c));
  }

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <p style={{ color: "var(--muted)" }}>Carregando...</p>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", padding: "1.5rem" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "2rem" }}>
        <div>
          <h1 style={{ fontSize: "1.5rem", fontWeight: 700, color: "var(--accent)" }}>Guilherme Agent</h1>
          <p style={{ color: "var(--muted)", fontSize: "0.875rem" }}>Painel de Vendas</p>
        </div>
        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <span className={health?.evolution === "WORKING" ? "badge-online" : "badge-offline"}>
            WhatsApp {health?.evolution === "WORKING" ? "Online" : health?.evolution ?? "..."}
          </span>
          <Link href="/agents" className="btn-ghost" style={{ textDecoration: "none", padding: "0.5rem 1rem", borderRadius: "0.375rem", border: "1px solid var(--card-border)", color: "var(--foreground)", fontSize: "0.875rem" }}>
            Agentes
          </Link>
          <Link href="/qrcode" className="btn-ghost" style={{ textDecoration: "none", padding: "0.5rem 1rem", borderRadius: "0.375rem", border: "1px solid var(--card-border)", color: "var(--foreground)", fontSize: "0.875rem" }}>
            QR Code
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1rem", marginBottom: "2rem" }}>
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "2rem", fontWeight: 700, color: "var(--accent)" }}>{conversations.length}</div>
          <div style={{ color: "var(--muted)", fontSize: "0.875rem" }}>Conversas</div>
        </div>
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "2rem", fontWeight: 700, color: "#22c55e" }}>
            {conversations.filter((c) => c.aiEnabled).length}
          </div>
          <div style={{ color: "var(--muted)", fontSize: "0.875rem" }}>IA Ativa</div>
        </div>
        <div className="card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "2rem", fontWeight: 700, color: "#f59e0b" }}>
            {conversations.filter((c) => c.handoffRequested).length}
          </div>
          <div style={{ color: "var(--muted)", fontSize: "0.875rem" }}>Handoff</div>
        </div>
      </div>

      {/* Conversas */}
      <div className="card">
        <h2 style={{ marginBottom: "1rem", fontWeight: 600 }}>Conversas Recentes</h2>
        {conversations.length === 0 ? (
          <p style={{ color: "var(--muted)", textAlign: "center", padding: "2rem 0" }}>
            Nenhuma conversa ainda. Aguardando mensagens no WhatsApp...
          </p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
            {conversations.map((conv) => (
              <div key={conv.id} style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "1rem", background: "#1a1a1a", borderRadius: "0.5rem",
                border: "1px solid var(--card-border)"
              }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600 }}>{conv.contact?.displayName ?? "Contato"}</div>
                  <div style={{ color: "var(--muted)", fontSize: "0.8rem", marginTop: "0.25rem" }}>
                    {conv.messages[0]?.content?.slice(0, 80) ?? "—"}
                  </div>
                  <div style={{ color: "var(--muted)", fontSize: "0.75rem", marginTop: "0.25rem" }}>
                    {new Date(conv.updatedAt).toLocaleString("pt-BR")}
                    {conv.handoffRequested && <span style={{ color: "#f59e0b", marginLeft: "0.5rem" }}>⚠ Handoff</span>}
                  </div>
                </div>
                <div style={{ display: "flex", gap: "0.5rem", marginLeft: "1rem" }}>
                  <Link
                    href={`/conversations/${conv.id}`}
                    style={{ fontSize: "0.8rem", padding: "0.375rem 0.75rem", borderRadius: "0.375rem", background: "#222", color: "var(--foreground)", textDecoration: "none", border: "1px solid var(--card-border)" }}
                  >
                    Ver
                  </Link>
                  <button
                    onClick={() => toggleAI(conv.id, conv.aiEnabled)}
                    style={{
                      fontSize: "0.8rem", padding: "0.375rem 0.75rem", borderRadius: "0.375rem",
                      background: conv.aiEnabled ? "#22c55e22" : "#ef444422",
                      color: conv.aiEnabled ? "#22c55e" : "#ef4444",
                      border: `1px solid ${conv.aiEnabled ? "#22c55e44" : "#ef444444"}`,
                      cursor: "pointer"
                    }}
                  >
                    {conv.aiEnabled ? "IA On" : "IA Off"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
