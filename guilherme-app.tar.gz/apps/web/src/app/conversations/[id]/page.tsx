"use client";
import { useEffect, useState, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";

interface Message { id: string; role: string; content: string; createdAt: string; }
interface ConvDetail {
  id: string; aiEnabled: boolean; handoffRequested: boolean; channel: string;
  contact: { displayName?: string };
  messages: Message[];
}

function getToken() {
  return document.cookie.split(";").find((c) => c.trim().startsWith("token="))?.split("=")[1] ?? "";
}

export default function ConversationPage() {
  const router = useRouter();
  const { id } = useParams() as { id: string };
  const [conv, setConv] = useState<ConvDetail | null>(null);
  const [reply, setReply] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function loadConv() {
    const token = getToken();
    if (!token) { router.push("/"); return; }
    const res = await fetch(`/api/conversations/${id}`, { headers: { authorization: `Bearer ${token}` } });
    if (!res.ok) return;
    setConv(await res.json());
  }

  useEffect(() => { loadConv(); const t = setInterval(loadConv, 5000); return () => clearInterval(t); }, [id]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [conv?.messages.length]);

  async function sendReply() {
    if (!reply.trim()) return;
    setSending(true);
    const token = getToken();
    await fetch(`/api/conversations/${id}/reply`, {
      method: "POST",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify({ text: reply }),
    });
    setReply("");
    await loadConv();
    setSending(false);
  }

  async function toggleAI() {
    if (!conv) return;
    const token = getToken();
    await fetch(`/api/conversations/${id}`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify({ aiEnabled: !conv.aiEnabled, handoffRequested: conv.aiEnabled ? false : conv.handoffRequested }),
    });
    await loadConv();
  }

  if (!conv) return <div style={{ padding: "2rem", color: "var(--muted)" }}>Carregando...</div>;

  return (
    <div style={{ minHeight: "100vh", padding: "1.5rem", maxWidth: 800, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "1.5rem" }}>
        <Link href="/dashboard" style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.875rem" }}>← Voltar</Link>
        <h1 style={{ flex: 1, fontWeight: 700 }}>{conv.contact?.displayName ?? "Contato"}</h1>
        <button
          onClick={toggleAI}
          style={{
            padding: "0.5rem 1rem", borderRadius: "0.375rem", cursor: "pointer",
            background: conv.aiEnabled ? "#22c55e22" : "#ef444422",
            color: conv.aiEnabled ? "#22c55e" : "#ef4444",
            border: `1px solid ${conv.aiEnabled ? "#22c55e44" : "#ef444444"}`
          }}
        >
          {conv.handoffRequested ? "Resolver Handoff" : conv.aiEnabled ? "Pausar IA" : "Reativar IA"}
        </button>
      </div>

      {/* Mensagens */}
      <div className="card" style={{ minHeight: 400, maxHeight: 500, overflowY: "auto", marginBottom: "1rem" }}>
        {conv.messages.map((msg) => (
          <div key={msg.id} style={{
            display: "flex", justifyContent: msg.role === "user" ? "flex-start" : "flex-end",
            marginBottom: "0.75rem"
          }}>
            <div style={{
              maxWidth: "75%", padding: "0.625rem 1rem", borderRadius: "1rem",
              background: msg.role === "user" ? "#1a1a1a" : "#adff2f22",
              border: `1px solid ${msg.role === "user" ? "var(--card-border)" : "#adff2f44"}`,
              color: msg.role === "user" ? "var(--foreground)" : "var(--accent)",
              fontSize: "0.9rem"
            }}>
              <div>{msg.content}</div>
              <div style={{ fontSize: "0.7rem", color: "var(--muted)", marginTop: "0.25rem", textAlign: "right" }}>
                {new Date(msg.createdAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
              </div>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Reply manual */}
      <div style={{ display: "flex", gap: "0.75rem" }}>
        <input
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendReply()}
          placeholder="Responder manualmente..."
          style={{
            flex: 1, padding: "0.625rem", background: "#1a1a1a",
            border: "1px solid var(--card-border)", borderRadius: "0.375rem",
            color: "var(--foreground)", outline: "none"
          }}
        />
        <button onClick={sendReply} className="btn-primary" disabled={sending}>
          {sending ? "..." : "Enviar"}
        </button>
      </div>
    </div>
  );
}
