"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

interface Agent { id: string; name: string; model: string; isDefault: boolean; ragDocs: unknown[]; }

function getToken() {
  return document.cookie.split(";").find((c) => c.trim().startsWith("token="))?.split("=")[1] ?? "";
}

export default function AgentsPage() {
  const router = useRouter();
  const [agents, setAgents] = useState<Agent[]>([]);

  useEffect(() => {
    const token = getToken();
    if (!token) { router.push("/"); return; }
    fetch("/api/agents", { headers: { authorization: `Bearer ${token}` } })
      .then((r) => r.json()).then(setAgents).catch(console.error);
  }, [router]);

  return (
    <div style={{ minHeight: "100vh", padding: "1.5rem" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem" }}>
        <Link href="/dashboard" style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.875rem" }}>← Voltar</Link>
        <h1 style={{ flex: 1, fontWeight: 700, color: "var(--accent)" }}>Agentes de IA</h1>
      </div>

      <div style={{ display: "grid", gap: "1rem" }}>
        {agents.map((agent) => (
          <div key={agent.id} className="card" style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 700 }}>
                {agent.name}
                {agent.isDefault && <span style={{ marginLeft: "0.5rem", fontSize: "0.75rem", color: "var(--accent)" }}>● Padrão</span>}
              </div>
              <div style={{ color: "var(--muted)", fontSize: "0.875rem" }}>
                {agent.model} · {agent.ragDocs?.length ?? 0} doc(s) no RAG
              </div>
            </div>
            <Link
              href={`/agents/${agent.id}`}
              style={{ padding: "0.5rem 1rem", borderRadius: "0.375rem", background: "#222", border: "1px solid var(--card-border)", color: "var(--foreground)", textDecoration: "none", fontSize: "0.875rem" }}
            >
              Editar
            </Link>
          </div>
        ))}
      </div>
    </div>
  );
}
