"use client";
import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";

interface Agent { id: string; name: string; systemPrompt: string; model: string; temperature: number; isDefault: boolean; ragDocs: Array<{ id: string; fileName: string; _count?: { chunks: number } }>; }

function getToken() {
  return document.cookie.split(";").find((c) => c.trim().startsWith("token="))?.split("=")[1] ?? "";
}

export default function AgentDetailPage() {
  const router = useRouter();
  const { id } = useParams() as { id: string };
  const [agent, setAgent] = useState<Agent | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [saved, setSaved] = useState(false);

  async function load() {
    const token = getToken();
    if (!token) { router.push("/"); return; }
    const res = await fetch(`/api/agents/${id}`, { headers: { authorization: `Bearer ${token}` } });
    if (res.ok) setAgent(await res.json());
  }

  useEffect(() => { load(); }, [id]);

  async function save() {
    if (!agent) return;
    setSaving(true);
    const token = getToken();
    await fetch(`/api/agents/${id}`, {
      method: "PATCH",
      headers: { authorization: `Bearer ${token}`, "content-type": "application/json" },
      body: JSON.stringify({ name: agent.name, systemPrompt: agent.systemPrompt, model: agent.model, temperature: agent.temperature }),
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function uploadDoc(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files?.[0] || !agent) return;
    setUploading(true);
    const form = new FormData();
    form.append("file", e.target.files[0]);
    form.append("agentSessionId", agent.id);
    const token = getToken();
    await fetch("/api/rag", { method: "POST", headers: { authorization: `Bearer ${token}` }, body: form });
    await load();
    setUploading(false);
  }

  if (!agent) return <div style={{ padding: "2rem", color: "var(--muted)" }}>Carregando...</div>;

  return (
    <div style={{ minHeight: "100vh", padding: "1.5rem", maxWidth: 700, margin: "0 auto" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "1rem", marginBottom: "2rem" }}>
        <Link href="/agents" style={{ color: "var(--muted)", textDecoration: "none", fontSize: "0.875rem" }}>← Agentes</Link>
        <h1 style={{ flex: 1, fontWeight: 700 }}>Editar: {agent.name}</h1>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
        <div className="card">
          <label style={{ fontSize: "0.875rem", color: "var(--muted)" }}>Nome do agente</label>
          <input value={agent.name} onChange={(e) => setAgent({ ...agent, name: e.target.value })}
            style={{ width: "100%", marginTop: "0.25rem", padding: "0.625rem", background: "#1a1a1a", border: "1px solid var(--card-border)", borderRadius: "0.375rem", color: "var(--foreground)", outline: "none", boxSizing: "border-box" }} />
        </div>

        <div className="card">
          <label style={{ fontSize: "0.875rem", color: "var(--muted)" }}>System Prompt (instrução do agente)</label>
          <textarea
            value={agent.systemPrompt}
            onChange={(e) => setAgent({ ...agent, systemPrompt: e.target.value })}
            rows={10}
            style={{ width: "100%", marginTop: "0.25rem", padding: "0.625rem", background: "#1a1a1a", border: "1px solid var(--card-border)", borderRadius: "0.375rem", color: "var(--foreground)", outline: "none", resize: "vertical", fontFamily: "inherit", boxSizing: "border-box" }}
          />
        </div>

        <div className="card">
          <label style={{ fontSize: "0.875rem", color: "var(--muted)" }}>Modelo</label>
          <select value={agent.model} onChange={(e) => setAgent({ ...agent, model: e.target.value })}
            style={{ width: "100%", marginTop: "0.25rem", padding: "0.625rem", background: "#1a1a1a", border: "1px solid var(--card-border)", borderRadius: "0.375rem", color: "var(--foreground)", outline: "none" }}>
            <option value="claude-sonnet-4-6">claude-sonnet-4-6 (Recomendado)</option>
            <option value="claude-haiku-4-5-20251001">claude-haiku-4-5 (Mais rápido)</option>
            <option value="claude-opus-4-6">claude-opus-4-6 (Mais inteligente)</option>
          </select>
        </div>

        <div className="card">
          <label style={{ fontSize: "0.875rem", color: "var(--muted)" }}>Criatividade (temperatura): {agent.temperature}</label>
          <input type="range" min="0" max="1" step="0.1" value={agent.temperature}
            onChange={(e) => setAgent({ ...agent, temperature: parseFloat(e.target.value) })}
            style={{ width: "100%", marginTop: "0.5rem", accentColor: "var(--accent)" }} />
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.75rem", color: "var(--muted)" }}>
            <span>Direto/Objetivo</span><span>Criativo/Variado</span>
          </div>
        </div>

        <button onClick={save} className="btn-primary" disabled={saving} style={{ alignSelf: "flex-start" }}>
          {saved ? "✓ Salvo!" : saving ? "Salvando..." : "Salvar Configurações"}
        </button>

        {/* RAG */}
        <div className="card">
          <h3 style={{ fontWeight: 600, marginBottom: "1rem" }}>Base de Conhecimento (RAG)</h3>
          <p style={{ color: "var(--muted)", fontSize: "0.875rem", marginBottom: "1rem" }}>
            Suba PDFs ou arquivos .txt com informações do seu negócio. O agente consulta antes de responder.
          </p>

          {agent.ragDocs.length > 0 && (
            <div style={{ marginBottom: "1rem" }}>
              {agent.ragDocs.map((doc) => (
                <div key={doc.id} style={{ padding: "0.5rem", background: "#1a1a1a", borderRadius: "0.375rem", marginBottom: "0.5rem", fontSize: "0.875rem", display: "flex", gap: "0.5rem" }}>
                  <span>📄</span>
                  <span>{doc.fileName}</span>
                </div>
              ))}
            </div>
          )}

          <label style={{ cursor: "pointer" }}>
            <div className="btn-ghost" style={{ display: "inline-block" }}>
              {uploading ? "Processando..." : "+ Subir documento"}
            </div>
            <input type="file" accept=".txt,.pdf,.md" onChange={uploadDoc} style={{ display: "none" }} disabled={uploading} />
          </label>
        </div>
      </div>
    </div>
  );
}
